// level0.js
window.levelConfigurations = {
    buildingHeight: 400,
    floorTot: 4,
    MAX_WEIGHT: 100,
    timer: 10,
    passengers: [
        { originFace: 'N', origin: 1, destination: 4, destinationFace: 'N', weight: 60 },
        { originFace: 'N', origin: 2, destination: 3, destinationFace: 'S', weight: 80 }
    ]
};