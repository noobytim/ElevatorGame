## Getting Started

Please download Visual Studio Code. 
Then open this folder in Visual Studio Code. 
On lefthand side bar, click on EXTENSIONS, and install Live Server. 
After installation, navigate back to explorer on sidebar, and right-click the index.html file and click "Open with Live Server" to open up the game in a browser.


**Sometimes the level refuses to load the level stage. 
Refresh the page and reclick the level button from the menu screen if so.